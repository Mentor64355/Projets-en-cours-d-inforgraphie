si c'est bien possible de me mettre en commentaire lors de la remse de ;a correction ou se trouve mon erreur dans les vs/fs
(parce que mes boules ne sont jamais lisse, et je ne comprend pas pourquoi). Merci!
