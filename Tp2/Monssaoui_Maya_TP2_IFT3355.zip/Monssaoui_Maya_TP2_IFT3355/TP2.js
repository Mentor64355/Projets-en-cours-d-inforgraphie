/**
*	[MOUSSAOUI]
*	[MAYA]
*	[20157653]
*/

import * as THREE from './build/three.module.js';

import Stats from './jsm/libs/stats.module.js';

import {
    ColladaLoader
}
    from './jsm/loaders/ColladaLoader.js';

import {
    OrbitControls
}
    from './jsm/controls/OrbitControls.js'

//SPECIAL IMPORT
// THREEx.KeyboardState.js keep the current state of the keyboard.
// It is possible to query it at any time. No need of an event.
// This is particularly convenient in loop driven case, like in
// 3D demos or games.
//
// # Usage
//
// **Step 1**: Create the object
//
// ```var keyboard	= new THREEx.KeyboardState();```
//
// **Step 2**: Query the keyboard state
//
// This will return true if shift and A are pressed, false otherwise
//
// ```keyboard.pressed("shift+A")```
//
// **Step 3**: Stop listening to the keyboard
//
// ```keyboard.destroy()```
//
// NOTE: this library may be nice as standaline. independant from three.js
// - rename it keyboardForGame
//
// # Code
//

/** @namespace */
var THREEx = THREEx || {};

/**
 * - NOTE: it would be quite easy to push event-driven too
 *   - microevent.js for events handling
 *   - in this._onkeyChange, generate a string from the DOM event
 *   - use this as event name
 */
THREEx.KeyboardState = function (domElement) {
    this.domElement = domElement || document;
    // to store the current state
    this.keyCodes = {};
    this.modifiers = {};

    // create callback to bind/unbind keyboard events
    var _this = this;
    this._onKeyDown = function (event) {
        _this._onKeyChange(event)
    }
    this._onKeyUp = function (event) {
        _this._onKeyChange(event)
    }

    // bind keyEvents
    this.domElement.addEventListener("keydown", this._onKeyDown, false);
    this.domElement.addEventListener("keyup", this._onKeyUp, false);

    // create callback to bind/unbind window blur event
    this._onBlur = function () {
        for (var prop in _this.keyCodes)
            _this.keyCodes[prop] = false;
        for (var prop in _this.modifiers)
            _this.modifiers[prop] = false;
    }

    // bind window blur
    window.addEventListener("blur", this._onBlur, false);
}

/**
 * To stop listening of the keyboard events
 */
THREEx.KeyboardState.prototype.destroy = function () {
    // unbind keyEvents
    this.domElement.removeEventListener("keydown", this._onKeyDown, false);
    this.domElement.removeEventListener("keyup", this._onKeyUp, false);

    // unbind window blur event
    window.removeEventListener("blur", this._onBlur, false);
}

THREEx.KeyboardState.MODIFIERS = ['shift', 'ctrl', 'alt', 'meta'];
THREEx.KeyboardState.ALIAS = {
    'left': 37,
    'up': 38,
    'right': 39,
    'down': 40,
    'space': 32,
    'pageup': 33,
    'pagedown': 34,
    'tab': 9,
    'escape': 27
};

/**
 * to process the keyboard dom event
 */
THREEx.KeyboardState.prototype._onKeyChange = function (event) {
    // log to debug
    //console.log("onKeyChange", event, event.keyCode, event.shiftKey, event.ctrlKey, event.altKey, event.metaKey)

    // update this.keyCodes
    var keyCode = event.keyCode
    var pressed = event.type === 'keydown' ? true : false
    this.keyCodes[keyCode] = pressed
    // update this.modifiers
    this.modifiers['shift'] = event.shiftKey
    this.modifiers['ctrl'] = event.ctrlKey
    this.modifiers['alt'] = event.altKey
    this.modifiers['meta'] = event.metaKey
}

/**
 * query keyboard state to know if a key is pressed of not
 *
 * @param {String} keyDesc the description of the key. format : modifiers+key e.g shift+A
 * @returns {Boolean} true if the key is pressed, false otherwise
 */
THREEx.KeyboardState.prototype.pressed = function (keyDesc) {
    var keys = keyDesc.split("+");
    for (var i = 0; i < keys.length; i++) {
        var key = keys[i]
        var pressed = false
        if (THREEx.KeyboardState.MODIFIERS.indexOf(key) !== -1) {
            pressed = this.modifiers[key];
        } else if (Object.keys(THREEx.KeyboardState.ALIAS).indexOf(key) != -1) {
            pressed = this.keyCodes[THREEx.KeyboardState.ALIAS[key]];
        } else {
            pressed = this.keyCodes[key.toUpperCase().charCodeAt(0)]
        }
        if (!pressed)
            return false;
    };
    return true;
}

/**
 * return true if an event match a keyDesc
 * @param  {KeyboardEvent} event   keyboard event
 * @param  {String} keyDesc string description of the key
 * @return {Boolean}         true if the event match keyDesc, false otherwise
 */
THREEx.KeyboardState.prototype.eventMatches = function (event, keyDesc) {
    var aliases = THREEx.KeyboardState.ALIAS
    var aliasKeys = Object.keys(aliases)
    var keys = keyDesc.split("+")
    // log to debug
    // console.log("eventMatches", event, event.keyCode, event.shiftKey, event.ctrlKey, event.altKey, event.metaKey)
    for (var i = 0; i < keys.length; i++) {
        var key = keys[i];
        var pressed = false;
        if (key === 'shift') {
            pressed = (event.shiftKey ? true : false)
        } else if (key === 'ctrl') {
            pressed = (event.ctrlKey ? true : false)
        } else if (key === 'alt') {
            pressed = (event.altKey ? true : false)
        } else if (key === 'meta') {
            pressed = (event.metaKey ? true : false)
        } else if (aliasKeys.indexOf(key) !== -1) {
            pressed = (event.keyCode === aliases[key] ? true : false);
        } else if (event.keyCode === key.toUpperCase().charCodeAt(0)) {
            pressed = true;
        }
        if (!pressed)
            return false;
    }
    return true;
}

let container, stats, clock, controls;
let lights, camera, scene, renderer, human, humanGeometry, humanMaterial, humanMesh, robot;
let skinWeight, skinIndices, boneArray, realBones, boneDict, centerOfMass;

THREE.Cache.enabled = true;


THREE.Object3D.prototype.setMatrix = function (a) {
    this.matrix = a;
    this.matrix.decompose(this.position, this.quaternion, this.scale);
};


class Robot {
    constructor(h) {
        this.spineLength = 0.65305;
        this.chestLength = 0.46487;
        this.neckLength = 0.24523
        this.headLength = 0.39284;

        this.armLength = 0.72111;
        this.forearmLength = 0.61242;
        this.legLength = 1.16245;
        this.shinLength = 1.03432;

        this.armLeftRotation = realBones[4].rotation;
        this.forearmLeftRotation = realBones[5].rotation;
        this.armRightRotation = realBones[6].rotation;
        this.forearmRightRotation = realBones[7].rotation;

        this.legLeftRotation = realBones[8].rotation;
        this.shinLeftRotation = realBones[9].rotation;
        this.legRightRotation = realBones[10].rotation;
        this.shinRightRotation = realBones[11].rotation;

        this.spineTranslation = realBones[0].position;
        this.chestTranslation = realBones[1].position;
        this.neckTranslation = realBones[2].position;
        this.headTranslation = realBones[3].position;
        this.armLeftTranslation = realBones[4].position;
        this.forearmLeftTranslation = realBones[5].position;
        this.armRightTranslation = realBones[6].position;
        this.forearmRightTranslation = realBones[7].position;

        this.legLeftTranslation = realBones[8].position;
        this.shinLeftTranslation = realBones[9].position;
        this.legRightTranslation = realBones[10].position;
        this.shinRightTranslation = realBones[11].position;


        this.bodyWidth = 0.2;
        this.bodyDepth = 0.2;


        this.neckRadius = 0.1;

        this.headRadius = 0.32;


        this.legRadius = 0.10;
        this.thighRadius = 0.1;
        this.footDepth = 0.4;
        this.footWidth = 0.25;

        this.armRadius = 0.10;

        this.handRadius = 0.1;

        // Material
        this.material = new THREE.MeshNormalMaterial();
        this.human = h;
        // Initial pose
        this.initialize()

    }

    initialize() {
        // Spine geomerty
        var spineGeometry = new THREE.CylinderGeometry(0.5 * this.bodyWidth / 2, this.bodyWidth / 2, this.spineLength, 64);
        if (!this.hasOwnProperty("spine"))
            this.spine = new THREE.Mesh(spineGeometry, this.material);

        // Spine geomerty 2 for second character
        var spineGeometry2 = new THREE.CylinderGeometry(0.5 * this.bodyWidth / 2, this.bodyWidth / 2, this.spineLength, 64);
        if (!this.hasOwnProperty("spine2"))
            this.spine2 = new THREE.Mesh(spineGeometry2, this.material);

        //chest geomerty
        var chestGeometry = new THREE.CylinderGeometry(0.5 * this.bodyWidth / 2, this.bodyWidth / 2, this.chestLength, 64);
        if (!this.hasOwnProperty("chest"))
            this.chest = new THREE.Mesh(chestGeometry, this.material);

        // chest geomerty 2 for second character
        var chestGeometry2 = new THREE.CylinderGeometry(0.5 * this.bodyWidth / 2, this.bodyWidth / 2, this.chestLength, 64);
        if (!this.hasOwnProperty("chest2"))
            this.chest2 = new THREE.Mesh(chestGeometry2, this.material);

        // Neck geomerty
        var neckGeometry = new THREE.CylinderGeometry(0.5 * this.neckRadius, this.neckRadius, this.neckLength, 64);
        if (!this.hasOwnProperty("neck"))
            this.neck = new THREE.Mesh(neckGeometry, this.material);

        // Neck geomerty 2 for second character
        var neckGeometry2 = new THREE.CylinderGeometry(0.5 * this.neckRadius, this.neckRadius, this.neckLength, 64);
        if (!this.hasOwnProperty("neck2"))
            this.neck2 = new THREE.Mesh(neckGeometry2, this.material);

        // Head geomerty
        var headGeometry = new THREE.SphereGeometry(this.headLength / 2, 64, 3);
        if (!this.hasOwnProperty("head"))
            this.head = new THREE.Mesh(headGeometry, this.material);
            
        // Head geomerty 2 for second character
        var headGeometry2 = new THREE.SphereGeometry(this.headLength / 2, 64, 3);
        if (!this.hasOwnProperty("head2"))
            this.head2 = new THREE.Mesh(headGeometry2, this.material);

        // arm Left geomerty
        var armLGeometry = new THREE.CylinderGeometry(0.5 * this.armRadius, this.armRadius, this.armLength, 64);
        if (!this.hasOwnProperty("arm_L"))
            this.armL = new THREE.Mesh(armLGeometry, this.material);
            
        // arm Left geomerty 2 for second character
        var armLGeometry2 = new THREE.CylinderGeometry(0.5 * this.armRadius, this.armRadius, this.armLength, 64);
        if (!this.hasOwnProperty("arm_L2"))
            this.armL2 = new THREE.Mesh(armLGeometry2, this.material);

        // arm Right geomerty
        var armRGeometry = new THREE.CylinderGeometry(0.5 * this.armRadius, this.armRadius, this.armLength, 64);
        if (!this.hasOwnProperty("arm_R"))
            this.armR = new THREE.Mesh(armRGeometry, this.material);

        // arm Right geomerty 2 for second character
        var armRGeometry2 = new THREE.CylinderGeometry(0.5 * this.armRadius, this.armRadius, this.armLength, 64);
        if (!this.hasOwnProperty("arm_R2"))
            this.armR2 = new THREE.Mesh(armRGeometry2, this.material);

        // forearm Left 
        var forearmLGeometry = new THREE.CylinderGeometry(0.5 * this.armRadius, this.armRadius, this.forearmLength, 64);
        if (!this.hasOwnProperty("forearm_L"))
            this.forearmL = new THREE.Mesh(forearmLGeometry, this.material);

        // forearm Left geomerty 2 for second character
        var forearmLGeometry2 = new THREE.CylinderGeometry(0.5 * this.armRadius, this.armRadius, this.forearmLength, 64);
        if (!this.hasOwnProperty("forearm_L2"))
            this.forearmL2 = new THREE.Mesh(forearmLGeometry2, this.material);

        // forearm Right
        var forearmRGeometry = new THREE.CylinderGeometry(0.5 * this.armRadius, this.armRadius, this.forearmLength, 64);
        if (!this.hasOwnProperty("forearm_R"))
            this.forearmR = new THREE.Mesh(forearmRGeometry, this.material);

        // forearm Right geomerty 2 for second character
        var forearmRGeometry2 = new THREE.CylinderGeometry(0.5 * this.armRadius, this.armRadius, this.forearmLength, 64);
        if (!this.hasOwnProperty("forearm_R2"))
            this.forearmR2 = new THREE.Mesh(forearmRGeometry2, this.material);

        // hand Left
        var handLGeometry = new THREE.SphereGeometry(this.handRadius, 64, 3);
        if (!this.hasOwnProperty("hand_L"))
            this.handL = new THREE.Mesh(handLGeometry, this.material);

        // hand Left geomerty 2 for second character
        var handLGeometry2 = new THREE.SphereGeometry(this.handRadius, 64, 3);
        if (!this.hasOwnProperty("hand_L2"))
            this.handL2 = new THREE.Mesh(handLGeometry2, this.material);

        // hand Right
        var handRGeometry = new THREE.SphereGeometry(this.handRadius, 64, 3);
        if (!this.hasOwnProperty("hand_L"))
            this.handR = new THREE.Mesh(handRGeometry, this.material);

        // hand Right geomerty 2 for second character
        var handRGeometry2 = new THREE.SphereGeometry(this.handRadius, 64, 3);
        if (!this.hasOwnProperty("hand_L2"))
            this.handR2 = new THREE.Mesh(handRGeometry2, this.material);

        // leg Left     
        var legLGeometry = new THREE.CylinderGeometry(0.5 * this.legRadius, this.legRadius, this.legLength, 64);
        if (!this.hasOwnProperty("leg_L"))
            this.legL = new THREE.Mesh(legLGeometry, this.material);

        // leg Left geomerty 2 for second character
        var legLGeometry2 = new THREE.CylinderGeometry(0.5 * this.legRadius, this.legRadius, this.legLength, 64);
        if (!this.hasOwnProperty("leg_L2"))
            this.legL2 = new THREE.Mesh(legLGeometry2, this.material);

        // leg Right 
        var legRGeometry = new THREE.CylinderGeometry(0.5 * this.legRadius, this.legRadius, this.legLength, 64);
        if (!this.hasOwnProperty("leg_R"))
            this.legR = new THREE.Mesh(legRGeometry, this.material);

        // leg Right geomerty 2 for second character
        var legRGeometry2 = new THREE.CylinderGeometry(0.5 * this.legRadius, this.legRadius, this.legLength, 64);
        if (!this.hasOwnProperty("leg_R2"))
            this.legR2 = new THREE.Mesh(legRGeometry2, this.material);

        // shin Left
        var shinLGeometry = new THREE.CylinderGeometry(0.5 * this.thighRadius, this.thighRadius, this.shinLength, 64);
        if (!this.hasOwnProperty("shin_L"))
            this.shinL = new THREE.Mesh(shinLGeometry, this.material);

        // shin Left geomerty 2 for second character
        var shinLGeometry2 = new THREE.CylinderGeometry(0.5 * this.thighRadius, this.thighRadius, this.shinLength, 64);
        if (!this.hasOwnProperty("shin_L2"))
            this.shinL2 = new THREE.Mesh(shinLGeometry2, this.material);

        // shin Right 
        var shinRGeometry = new THREE.CylinderGeometry(0.5 * this.thighRadius, this.thighRadius, this.shinLength, 64);
        if (!this.hasOwnProperty("shin_R"))
            this.shinR = new THREE.Mesh(shinRGeometry, this.material);

        // shin Right geomerty 2 for second character
        var shinRGeometry2 = new THREE.CylinderGeometry(0.5 * this.thighRadius, this.thighRadius, this.shinLength, 64);
        if (!this.hasOwnProperty("shin_R2"))
            this.shinR2 = new THREE.Mesh(shinRGeometry2, this.material);

        // foot Left
        var footLGeometry = new THREE.BoxGeometry(this.footWidth, this.footWidth / 2, this.footDepth);
        if (!this.hasOwnProperty("foot_L"))
            this.footL = new THREE.Mesh(footLGeometry, this.material);

        // foot Left geomerty 2 for second character
        var footLGeometry2 = new THREE.BoxGeometry(this.footWidth, this.footWidth / 2, this.footDepth);
        if (!this.hasOwnProperty("foot_L2"))
            this.footL2 = new THREE.Mesh(footLGeometry2, this.material);

        // foot Right
        var footRGeometry = new THREE.BoxGeometry(this.footWidth, this.footWidth / 2, this.footDepth);
        if (!this.hasOwnProperty("foot_R"))
            this.footR = new THREE.Mesh(footRGeometry, this.material);

        // foot Right geomerty 2 for second character
        var footRGeometry2 = new THREE.BoxGeometry(this.footWidth, this.footWidth / 2, this.footDepth);
        if (!this.hasOwnProperty("foot_R2"))
            this.footR2 = new THREE.Mesh(footRGeometry2, this.material);

        


        // Spine matrix
        this.spineMatrix = new THREE.Matrix4().set(

            1, 0, 0, 0,
            0, 1, 0, this.spineTranslation.y + this.spineLength / 2,
            0, 0, 1, 0,
            0, 0, 0, 1);

        // Spine matrix for second character
        this.spineMatrix2 = new THREE.Matrix4().set(

            1, 0, 0, 0,
            0, 1, 0, this.spineTranslation.y + this.spineLength / 2,
            0, 0, 1, 5,
            0, 0, 0, 1);

        // chest matrix
        this.chestMatrix = new THREE.Matrix4().set(

            1, 0, 0, 0,
            0, 1, 0, this.chestTranslation.y - this.spineLength / 2 + this.chestLength / 2,
            0, 0, 1, 0,
            0, 0, 0, 1);
        var chestMatrix = new THREE.Matrix4().multiplyMatrices(this.spineMatrix, this.chestMatrix);

        // chest matrix for second character
        var chestMatrix2 = new THREE.Matrix4().multiplyMatrices(this.spineMatrix2, this.chestMatrix);



        // Neck matrix
        this.neckMatrix = new THREE.Matrix4().set(
            1, 0, 0, 0,
            0, 1, 0, this.neckTranslation.y - this.chestLength / 2 + this.neckLength / 2,
            0, 0, 1, 0,
            0, 0, 0, 1);
        var neckMatrix = new THREE.Matrix4().multiplyMatrices(chestMatrix, this.neckMatrix);

        // Neck matrix for second character
        var neckMatrix2 = new THREE.Matrix4().multiplyMatrices(chestMatrix2, this.neckMatrix);


        // Head matrix
        this.headMatrix = new THREE.Matrix4().set(
            1, 0, 0, 0,
            0, 1, 0, this.headTranslation.y - this.neckLength / 2 + this.headLength / 2,
            0, 0, 1, 0,
            0, 0, 0, 1);
        var headMatrix = new THREE.Matrix4().multiplyMatrices(neckMatrix, this.headMatrix);

        // Head matrix for second character
        var headMatrix2 = new THREE.Matrix4().multiplyMatrices(neckMatrix2, this.headMatrix);


        // arm Left matrix
        this.armLMatrix = new THREE.Matrix4().set(
            1, 0, 0, 0,
            0, 1, 0, this.armLength / 2,
            0, 0, 1, 0,
            0, 0, 0, 1);

        var rotArmLmatrix = matMul(matMul(rotZ(this.armLeftRotation.z), rotY(this.armLeftRotation.y)), rotX(this.armLeftRotation.x));
        var transArmLmatrix = translation(this.armLeftTranslation.x, this.armLeftTranslation.y - this.chestLength / 2, this.armLeftTranslation.z)
        var armLMatrix = matMul(transArmLmatrix, matMul(rotArmLmatrix, this.armLMatrix));

        // arm Left matrix for second character
        var armLMatrix2 = new THREE.Matrix4().multiplyMatrices(chestMatrix2, armLMatrix);

        armLMatrix = new THREE.Matrix4().multiplyMatrices(chestMatrix, armLMatrix);
        

        // arm Right matrix
        this.armRMatrix = new THREE.Matrix4().set(
            1, 0, 0, 0,
            0, 1, 0, this.armLength / 2,
            0, 0, 1, 0,
            0, 0, 0, 1);

        var rotArmRmatrix = matMul(matMul(rotZ(this.armRightRotation.z), rotY(this.armRightRotation.y)), rotX(this.armRightRotation.x));
        var transArmRmatrix = translation(this.armRightTranslation.x, this.armRightTranslation.y - this.chestLength / 2, this.armRightTranslation.z)
        var armRMatrix = matMul(transArmRmatrix, matMul(rotArmRmatrix, this.armRMatrix));

        // arm Right matrix for second character
        var armRMatrix2 = new THREE.Matrix4().multiplyMatrices(chestMatrix2, armRMatrix);

        armRMatrix = new THREE.Matrix4().multiplyMatrices(chestMatrix, armRMatrix);
        

        // forearm Left matrix
        this.forearmLMatrix = new THREE.Matrix4().set(
            1, 0, 0, 0,
            0, 1, 0, this.forearmLength / 2,
            0, 0, 1, 0,
            0, 0, 0, 1);

        var rotForearmLmatrix = matMul(matMul(rotZ(this.forearmLeftRotation.z), rotY(this.forearmLeftRotation.y)), rotX(this.forearmLeftRotation.x));
        var transForearmLmatrix = translation(this.forearmLeftTranslation.x, this.forearmLeftTranslation.y - this.armLength / 2, this.forearmLeftTranslation.z)
        var forearmLMatrix = matMul(transForearmLmatrix, matMul(rotForearmLmatrix, this.forearmLMatrix));

        // forearm Left matrix for second character
        var forearmLMatrix2 = new THREE.Matrix4().multiplyMatrices(armLMatrix2, forearmLMatrix);

        forearmLMatrix = new THREE.Matrix4().multiplyMatrices(armLMatrix, forearmLMatrix);
        

        this.forearmRMatrix = new THREE.Matrix4().set(
            1, 0, 0, 0,
            0, 1, 0, this.forearmLength / 2,
            0, 0, 1, 0,
            0, 0, 0, 1);

        var rotForearmRmatrix = matMul(matMul(rotZ(this.forearmRightRotation.z), rotY(this.forearmRightRotation.y)), rotX(this.forearmRightRotation.x));
        var transForearmRmatrix = translation(this.forearmRightTranslation.x, this.forearmRightTranslation.y - this.armLength / 2, this.forearmRightTranslation.z)
        var forearmRMatrix = matMul(transForearmRmatrix, matMul(rotForearmRmatrix, this.forearmRMatrix));
        
        // forearm Right matrix for second character
        var forearmRMatrix2 = new THREE.Matrix4().multiplyMatrices(armRMatrix2, forearmRMatrix);

        forearmRMatrix = new THREE.Matrix4().multiplyMatrices(armRMatrix, forearmRMatrix);
        

        // hand Left matrix
        this.handLMatrix = new THREE.Matrix4().set(
            1, 0, 0, 0,
            0, 1, 0, this.handRadius / 2 + this.forearmLength / 2,
            0, 0, 1, 0,
            0, 0, 0, 1);

        var handLMatrix = new THREE.Matrix4().multiplyMatrices(forearmLMatrix, this.handLMatrix);

        // hand Left matrix for second character
        var handLMatrix2 = new THREE.Matrix4().multiplyMatrices(forearmLMatrix2, this.handLMatrix);

        // hand Right matrix
        this.handRMatrix = new THREE.Matrix4().set(
            1, 0, 0, 0,
            0, 1, 0, this.handRadius / 2 + this.forearmLength / 2,
            0, 0, 1, 0,
            0, 0, 0, 1);

        var handRMatrix = new THREE.Matrix4().multiplyMatrices(forearmRMatrix, this.handRMatrix);

        // hand Right matrix for second character
        var handRMatrix2 = new THREE.Matrix4().multiplyMatrices(forearmRMatrix2, this.handRMatrix);

        // leg Left matrix
        this.legLMatrix = new THREE.Matrix4().set(
            1, 0, 0, 0,
            0, 1, 0, this.legLength / 2,
            0, 0, 1, 0,
            0, 0, 0, 1);

        var rotLegLmatrix = matMul(matMul(rotZ(this.legLeftRotation.z), rotY(this.legLeftRotation.y)), rotX(-this.legLeftRotation.x));
        var transLegLmatrix = translation(this.legLeftTranslation.x, this.legLeftTranslation.y - this.spineLength / 2, this.legLeftTranslation.z)
        var legLMatrix = matMul(transLegLmatrix, matMul(rotLegLmatrix, this.legLMatrix));

        // leg Left matrix for second character
        var legLMatrix2 = new THREE.Matrix4().multiplyMatrices(this.spineMatrix2, legLMatrix);

        legLMatrix = new THREE.Matrix4().multiplyMatrices(this.spineMatrix, legLMatrix);
        

        // leg Right matrix
        this.legRMatrix = new THREE.Matrix4().set(
            1, 0, 0, 0,
            0, 1, 0, this.legLength / 2,
            0, 0, 1, 0,
            0, 0, 0, 1);

        var rotLegRmatrix = matMul(matMul(rotZ(this.legRightRotation.z), rotY(this.legRightRotation.y)), rotX(-this.legRightRotation.x));
        var transLegRmatrix = translation(this.legRightTranslation.x, this.legRightTranslation.y - this.spineLength / 2, this.legRightTranslation.z)
        var legRMatrix = matMul(transLegRmatrix, matMul(rotLegRmatrix, this.legRMatrix));

        // leg Right matrix for second character
        var legRMatrix2 = new THREE.Matrix4().multiplyMatrices(this.spineMatrix2, legRMatrix);

        legRMatrix = new THREE.Matrix4().multiplyMatrices(this.spineMatrix, legRMatrix);
        

        // shin Left matrix
        this.shinLMatrix = new THREE.Matrix4().set(
            1, 0, 0, 0,
            0, 1, 0, this.legLength / 2,
            0, 0, 1, 0,
            0, 0, 0, 1);

        var rotShinLmatrix = matMul(matMul(rotZ(this.shinLeftRotation.z), rotY(this.shinLeftRotation.y)), rotX(this.shinLeftRotation.x));
        var transShinLmatrix = translation(this.shinLeftTranslation.x, this.shinLeftTranslation.y - this.legLength / 2, this.shinLeftTranslation.z)
        var shinLMatrix = matMul(transShinLmatrix, matMul(rotShinLmatrix, this.shinLMatrix));

        // shin Left matrix for second character
        var shinLMatrix2 = new THREE.Matrix4().multiplyMatrices(legLMatrix2, shinLMatrix);

        shinLMatrix = new THREE.Matrix4().multiplyMatrices(legLMatrix, shinLMatrix);
        

        // shin Right matrix
        this.shinRMatrix = new THREE.Matrix4().set(
            1, 0, 0, 0,
            0, 1, 0, this.legLength / 2,
            0, 0, 1, 0,
            0, 0, 0, 1);

        var rotShinRmatrix = matMul(matMul(rotZ(this.shinRightRotation.z), rotY(this.shinRightRotation.y)), rotX(this.shinRightRotation.x));
        var transShinRmatrix = translation(this.shinRightTranslation.x, this.shinRightTranslation.y - this.legLength / 2, this.shinRightTranslation.z)
        var shinRMatrix = matMul(transShinRmatrix, matMul(rotShinRmatrix, this.shinRMatrix));

        // shin Right matrix for second character
        var shinRMatrix2 = new THREE.Matrix4().multiplyMatrices(legRMatrix2, shinRMatrix);

        shinRMatrix = new THREE.Matrix4().multiplyMatrices(legRMatrix, shinRMatrix);
        

        // foot Left matrix
        this.footLMatrix = new THREE.Matrix4().set(

            1, 0, 0, 0,
            0, 1, 0, this.shinLength - this.footDepth / 2 - this.footWidth,
            0, 0, 1, 0,
            0, 0, 0, 1);
        var footLMatrix = new THREE.Matrix4().multiplyMatrices(shinLMatrix, this.footLMatrix);

        // foot Left matrix for second character
        var footLMatrix2 = new THREE.Matrix4().multiplyMatrices(shinLMatrix2, this.footLMatrix);

        // foot Right matrix
        this.footRMatrix = new THREE.Matrix4().set(

            1, 0, 0, 0,
            0, 1, 0, this.shinLength - this.footDepth / 2 - this.footWidth,
            0, 0, 1, 0,
            0, 0, 0, 1);
        var footRMatrix = new THREE.Matrix4().multiplyMatrices(shinRMatrix, this.footRMatrix);

        // foot Right matrix for second character
        var footRMatrix2 = new THREE.Matrix4().multiplyMatrices(shinRMatrix2, this.footRMatrix);




        // Apply transformation
        this.spine.setMatrix(this.spineMatrix);
        if (scene.getObjectById(this.spine.id) === undefined)
            scene.add(this.spine);

        this.spine2.setMatrix(this.spineMatrix2);
        if (scene.getObjectById(this.spine2.id) === undefined)
            scene.add(this.spine2);
        this.spine2.visible = false;

        this.chest.setMatrix(chestMatrix);
        if (scene.getObjectById(this.chest.id) === undefined)
            scene.add(this.chest);

        this.chest2.setMatrix(chestMatrix2);
        if (scene.getObjectById(this.chest2.id) === undefined)
            scene.add(this.chest2);
        this.chest2.visible = false;

        this.neck.setMatrix(neckMatrix);
        if (scene.getObjectById(this.neck.id) === undefined)
            scene.add(this.neck);
            
        this.neck2.setMatrix(neckMatrix2);
        if (scene.getObjectById(this.neck2.id) === undefined)
            scene.add(this.neck2);
        this.neck2.visible = false;

        this.head.setMatrix(headMatrix);
        if (scene.getObjectById(this.head.id) === undefined)
            scene.add(this.head);
            
        this.head2.setMatrix(headMatrix2);
        if (scene.getObjectById(this.head2.id) === undefined)
            scene.add(this.head2);
        this.head2.visible = false;

        this.armL.setMatrix(armLMatrix);
        if (scene.getObjectById(this.armL.id) === undefined)
            scene.add(this.armL);

        this.armL2.setMatrix(armLMatrix2);
        if (scene.getObjectById(this.armL2.id) === undefined)
            scene.add(this.armL2);
        this.armL2.visible = false;

        this.armR.setMatrix(armRMatrix);
        if (scene.getObjectById(this.armR.id) === undefined)
            scene.add(this.armR);

        this.armR2.setMatrix(armRMatrix2);
        if (scene.getObjectById(this.armR2.id) === undefined)
            scene.add(this.armR2);
        this.armR2.visible = false;

        this.forearmL.setMatrix(forearmLMatrix);
        if (scene.getObjectById(this.forearmL.id) === undefined)
            scene.add(this.forearmL);

        this.forearmL2.setMatrix(forearmLMatrix2);
        if (scene.getObjectById(this.forearmL2.id) === undefined)
            scene.add(this.forearmL2);
        this.forearmL2.visible = false;

        this.forearmR.setMatrix(forearmRMatrix);
        if (scene.getObjectById(this.forearmR.id) === undefined)
            scene.add(this.forearmR);

        this.forearmR2.setMatrix(forearmRMatrix2);
        if (scene.getObjectById(this.forearmR2.id) === undefined)
            scene.add(this.forearmR2);
        this.forearmR2.visible = false;

        this.handL.setMatrix(handLMatrix);
        if (scene.getObjectById(this.handL.id) === undefined)
            scene.add(this.handL);

        this.handL2.setMatrix(handLMatrix2);
        if (scene.getObjectById(this.handL2.id) === undefined)
            scene.add(this.handL2);
        this.handL2.visible = false;

        this.handR.setMatrix(handRMatrix);
        if (scene.getObjectById(this.handR.id) === undefined)
            scene.add(this.handR);

        this.handR2.setMatrix(handRMatrix2);
        if (scene.getObjectById(this.handR.id2) === undefined)
            scene.add(this.handR2);
        this.handR2.visible = false;

        this.legL.setMatrix(legLMatrix);
        if (scene.getObjectById(this.legL.id) === undefined)
            scene.add(this.legL);

        this.legL2.setMatrix(legLMatrix2);
        if (scene.getObjectById(this.legL2.id) === undefined)
            scene.add(this.legL2);
        this.legL2.visible = false;

        this.legR.setMatrix(legRMatrix);
        if (scene.getObjectById(this.legR.id) === undefined)
            scene.add(this.legR);

        this.legR2.setMatrix(legRMatrix2);
        if (scene.getObjectById(this.legR2.id) === undefined)
            scene.add(this.legR2);
        this.legR2.visible = false;

        this.shinL.setMatrix(shinLMatrix);
        if (scene.getObjectById(this.shinL.id) === undefined)
            scene.add(this.shinL);

        this.shinL2.setMatrix(shinLMatrix2);
        if (scene.getObjectById(this.shinL2.id) === undefined)
            scene.add(this.shinL2);
        this.shinL2.visible = false;

        this.shinR.setMatrix(shinRMatrix);
        if (scene.getObjectById(this.shinR.id) === undefined)
            scene.add(this.shinR);

        this.shinR2.setMatrix(shinRMatrix2);
        if (scene.getObjectById(this.shinR2.id) === undefined)
            scene.add(this.shinR2);
        this.shinR2.visible = false;

        this.footL.setMatrix(footLMatrix);
        if (scene.getObjectById(this.footL.id) === undefined)
            scene.add(this.footL);

        this.footL2.setMatrix(footLMatrix2);
        if (scene.getObjectById(this.footL2.id) === undefined)
            scene.add(this.footL2);
        this.footL2.visible = false;

        this.footR.setMatrix(footRMatrix);
        if (scene.getObjectById(this.footR.id) === undefined)
            scene.add(this.footR);

        this.footR2.setMatrix(footRMatrix2);
        if (scene.getObjectById(this.footR2.id) === undefined)
            scene.add(this.footR2);
        this.footR2.visible = false;
        
        // for (var key in boneDict) {
        //     if(key == "Spine"){
        //         boneDict[key].matrix = matMul(this.spineMatrix, inverseOf(boneDict[key].matrix));
        //     }
        //     else if(key == "Chest"){
        //         boneDict[key].matrix = matMul(chestMatrix, inverseOf(boneDict[key].matrix));
        //     }
        //     else if(key == "Neck"){
        //         boneDict[key].matrix =  matMul(neckMatrix, inverseOf(boneDict[key].matrix));
        //     }
        //     else if(key == "Head"){
        //         boneDict[key].matrix =  matMul(headMatrix, inverseOf(boneDict[key].matrix));
        //     }
        //     else if(key == "Arm_L"){
        //         boneDict[key].matrix = matMul(armLMatrix, inverseOf(boneDict[key].matrix));
        //     }
        //     else if(key == "Forearm_L"){
        //         boneDict[key].matrix =  matMul(forearmLMatrix, inverseOf(boneDict[key].matrix));
        //     }
        //     else if(key == "Arm_R"){
        //         boneDict[key].matrix =  matMul(armRMatrix, inverseOf(boneDict[key].matrix));
        //     }
        //     else if(key == "Forearm_R"){
        //         boneDict[key].matrix =  matMul(forearmRMatrix, inverseOf(boneDict[key].matrix));
        //     }
        //     else if(key == "Leg_L"){
        //         boneDict[key].matrix =  matMul(legLMatrix, inverseOf(boneDict[key].matrix));
        //     }
        //     else if(key == "Shin_L"){
        //         boneDict[key].matrix =  matMul(shinLMatrix, inverseOf(boneDict[key].matrix));
        //     }
        //     else if(key == "Leg_R"){
        //         boneDict[key].matrix =  matMul(legRMatrix, inverseOf(boneDict[key].matrix));
        //     }
        //     else if(key == "Shin_R"){
        //         boneDict[key].matrix =  matMul(shinRMatrix, inverseOf(boneDict[key].matrix));
        //     }
        // }

    }

    hideRobot() {
        this.spine.visible = false;
        this.chest.visible = false;
        this.neck.visible = false;
        this.head.visible = false;
        this.armL.visible = false;
        this.armR.visible = false;
        this.forearmL.visible = false;
        this.forearmR.visible = false;
        this.handL.visible = false;
        this.handR.visible = false;
        this.legL.visible = false;
        this.legR.visible = false;
        this.shinL.visible = false;
        this.shinR.visible = false;
        this.footL.visible = false;
        this.footR.visible = false;
        
    }
    hideHuman() {
        this.human.visible = false;
    }

    showRobot() {
        this.spine.visible = true;
        this.chest.visible = true;
        this.neck.visible = true;
        this.head.visible = true;
        this.armL.visible = true;
        this.armR.visible = true;
        this.forearmL.visible = true;
        this.forearmR.visible = true;
        this.handL.visible = true;
        this.handR.visible = true;
        this.legL.visible = true;
        this.legR.visible = true;
        this.shinL.visible = true;
        this.shinR.visible = true;
        this.footL.visible = true;
        this.footR.visible = true;
    }
    showHuman() {
        this.human.visible = true;
    }

    pose1() {
        robot.hideSupp();
        this.spineMatrix = new THREE.Matrix4().set(

            1, 0, 0, 0,
            0, 1, 0, this.spineTranslation.y + this.spineLength / 2,
            0, 0, 1, 0,
            0, 0, 0, 1);

        var spineMatrix = new THREE.Matrix4().multiplyMatrices(rotX(-0.1), this.spineMatrix);
        // var spineMatrix = this.spineMatrix;
        this.spine.setMatrix(spineMatrix);

        // chest
        var chestMatrix = new THREE.Matrix4().multiplyMatrices(spineMatrix, this.chestMatrix);
        this.chest.setMatrix(chestMatrix);

        // neck
        var neckMatrix = new THREE.Matrix4().multiplyMatrices(chestMatrix, this.neckMatrix);
        this.neck.setMatrix(neckMatrix);

        // head
        var headMatrix = new THREE.Matrix4().multiplyMatrices(neckMatrix, this.headMatrix);
        this.head.setMatrix(headMatrix);

        // modifications arm left
        var rotArmLmatrix = matMul(matMul(rotZ(-1.9), rotY(1)), rotX(-0.2));
        var transArmLmatrix = translation(this.armLeftTranslation.x, this.armLeftTranslation.y - this.chestLength / 2, this.armLeftTranslation.z)
        var armLMatrix = matMul(transArmLmatrix, matMul(rotArmLmatrix, this.armLMatrix));
        armLMatrix = new THREE.Matrix4().multiplyMatrices(chestMatrix, armLMatrix);
        this.armL.setMatrix(armLMatrix);

        // modifications arm right
        var rotArmRmatrix = matMul(matMul(rotZ(2.5), rotY(-1)), rotX(0.2));
        var transArmRmatrix = translation(this.armRightTranslation.x, this.armRightTranslation.y - this.chestLength / 2, this.armRightTranslation.z)
        var armRMatrix = matMul(transArmRmatrix, matMul(rotArmRmatrix, this.armRMatrix));
        armRMatrix = new THREE.Matrix4().multiplyMatrices(chestMatrix, armRMatrix);
        this.armR.setMatrix(armRMatrix);

        //modifications forearm left
        var rotForearmLmatrix = matMul(matMul(rotZ(0), rotY(0.1)), rotX(-1.5));
        var transForearmLmatrix = translation(this.forearmLeftTranslation.x, this.forearmLeftTranslation.y - this.armLength / 2, this.forearmLeftTranslation.z)
        var forearmLMatrix = matMul(transForearmLmatrix, matMul(rotForearmLmatrix, this.forearmLMatrix));
        forearmLMatrix = new THREE.Matrix4().multiplyMatrices(armLMatrix, forearmLMatrix);
        this.forearmL.setMatrix(forearmLMatrix);

        //modifications forearm right
        var rotForearmRmatrix = matMul(matMul(rotZ(0.3), rotY(0)), rotX(2));
        var transForearmRmatrix = translation(this.forearmRightTranslation.x, this.forearmRightTranslation.y - this.armLength / 2, this.forearmRightTranslation.z)
        var forearmRMatrix = matMul(transForearmRmatrix, matMul(rotForearmRmatrix, this.forearmRMatrix));
        forearmRMatrix = new THREE.Matrix4().multiplyMatrices(armRMatrix, forearmRMatrix);
        this.forearmR.setMatrix(forearmRMatrix);

        //modifications hand left
        var handLMatrix = new THREE.Matrix4().multiplyMatrices(forearmLMatrix, this.handLMatrix);
        this.handL.setMatrix(handLMatrix);

        //modifications hand left
        var handRMatrix = new THREE.Matrix4().multiplyMatrices(forearmRMatrix, this.handRMatrix);
        this.handR.setMatrix(handRMatrix);

        //modifications leg left
        var rotLegLmatrix = matMul(matMul(rotZ(0), rotY(0.4)), rotX(-2.8));
        var transLegLmatrix = translation(this.legLeftTranslation.x, this.legLeftTranslation.y - this.spineLength / 2, this.legLeftTranslation.z)
        var legLMatrix = matMul(transLegLmatrix, matMul(rotLegLmatrix, this.legLMatrix));
        legLMatrix = new THREE.Matrix4().multiplyMatrices(this.spineMatrix, legLMatrix);
        this.legL.setMatrix(legLMatrix);

        //modifications lef right
        var rotLegRmatrix = matMul(matMul(rotZ(0), rotY(0.2)), rotX(2.8));
        var transLegRmatrix = translation(this.legRightTranslation.x, this.legRightTranslation.y - this.spineLength / 2, this.legRightTranslation.z)
        var legRMatrix = matMul(transLegRmatrix, matMul(rotLegRmatrix, this.legRMatrix));
        legRMatrix = new THREE.Matrix4().multiplyMatrices(this.spineMatrix, legRMatrix);
        this.legR.setMatrix(legRMatrix);

        //modifications shin left
        var rotShinLmatrix = matMul(matMul(rotZ(0), rotY(0)), rotX(0));
        var transShinLmatrix = translation(this.shinLeftTranslation.x, this.shinLeftTranslation.y - this.legLength / 2, this.shinLeftTranslation.z)
        var shinLMatrix = matMul(transShinLmatrix, matMul(rotShinLmatrix, this.shinLMatrix));
        shinLMatrix = new THREE.Matrix4().multiplyMatrices(legLMatrix, shinLMatrix);
        this.shinL.setMatrix(shinLMatrix);

        //modifications shin right
        var rotShinRmatrix = matMul(matMul(rotZ(0), rotY(0)), rotX(0));
        var transShinRmatrix = translation(this.shinRightTranslation.x, this.shinRightTranslation.y - this.legLength / 2, this.shinRightTranslation.z)
        var shinRMatrix = matMul(transShinRmatrix, matMul(rotShinRmatrix, this.shinRMatrix));
        shinRMatrix = new THREE.Matrix4().multiplyMatrices(legRMatrix, shinRMatrix);
        this.shinR.setMatrix(shinRMatrix);

        //foot left
        var footLMatrix = new THREE.Matrix4().multiplyMatrices(shinLMatrix, this.footLMatrix);
        this.footL.setMatrix(footLMatrix);

        //foot right
        var footRMatrix = new THREE.Matrix4().multiplyMatrices(shinRMatrix, this.footRMatrix);
        this.footR.setMatrix(footRMatrix);

        // le set des nouvelles matrice de transformation pour shader
        for (var key in boneDict) {
            if(key == "Spine"){
                boneDict[key].matrix = matMul(spineMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Chest"){
                boneDict[key].matrix = matMul(chestMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Neck"){
                boneDict[key].matrix =  matMul(neckMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Head"){
                boneDict[key].matrix =  matMul(headMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Arm_L"){
                boneDict[key].matrix = matMul(armLMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Forearm_L"){
                boneDict[key].matrix =  matMul(forearmLMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Arm_R"){
                boneDict[key].matrix =  matMul(armRMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Forearm_R"){
                boneDict[key].matrix =  matMul(forearmRMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Leg_L"){
                boneDict[key].matrix =  matMul(legLMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Shin_L"){
                boneDict[key].matrix =  matMul(shinLMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Leg_R"){
                boneDict[key].matrix =  matMul(legRMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Shin_R"){
                boneDict[key].matrix =  matMul(shinRMatrix, inverseOf(boneDict[key].matrix));
            }
        }
        buildShaderBoneMatrix();
    }

    pose2() {
        robot.hideSupp();

        // spine
        this.spineMatrix = new THREE.Matrix4().set(

            1, 0, 0, 0,
            0, 1, 0, this.spineTranslation.y + this.spineLength / 2,
            0, 0, 1, 0,
            0, 0, 0, 1);
        var spineMatrix = new THREE.Matrix4().multiplyMatrices(rotX(0), this.spineMatrix);
        this.spine.setMatrix(spineMatrix);

        // chest
        var chestMatrix = new THREE.Matrix4().multiplyMatrices(spineMatrix, this.chestMatrix);
        this.chest.setMatrix(chestMatrix);

        // neck
        var neckMatrix = new THREE.Matrix4().multiplyMatrices(chestMatrix, this.neckMatrix);
        this.neck.setMatrix(neckMatrix);

        // head
        var headMatrix = new THREE.Matrix4().multiplyMatrices(neckMatrix, this.headMatrix);
        this.head.setMatrix(headMatrix);

        // modifications arm left
        var rotArmLmatrix = matMul(matMul(rotZ(- Math.PI / 2), rotY(0)), rotX(0));
        var transArmLmatrix = translation(this.armLeftTranslation.x, this.armLeftTranslation.y - this.chestLength / 2, this.armLeftTranslation.z)
        var armLMatrix = matMul(transArmLmatrix, matMul(rotArmLmatrix, this.armLMatrix));
        armLMatrix = new THREE.Matrix4().multiplyMatrices(chestMatrix, armLMatrix);
        this.armL.setMatrix(armLMatrix);

        // modifications arm right
        var rotArmRmatrix = matMul(matMul(rotZ(Math.PI / 2), rotY(0)), rotX(0));
        var transArmRmatrix = translation(this.armRightTranslation.x, this.armRightTranslation.y - this.chestLength / 2, this.armRightTranslation.z)
        var armRMatrix = matMul(transArmRmatrix, matMul(rotArmRmatrix, this.armRMatrix));
        armRMatrix = new THREE.Matrix4().multiplyMatrices(chestMatrix, armRMatrix);
        this.armR.setMatrix(armRMatrix);

        // //modifications forearm left
        var rotForearmLmatrix = matMul(matMul(rotZ(0), rotY(0)), rotX(0));
        var transForearmLmatrix = translation(this.forearmLeftTranslation.x, this.forearmLeftTranslation.y - this.armLength / 2, this.forearmLeftTranslation.z)
        var forearmLMatrix = matMul(transForearmLmatrix, matMul(rotForearmLmatrix, this.forearmLMatrix));
        forearmLMatrix = new THREE.Matrix4().multiplyMatrices(armLMatrix, forearmLMatrix);
        this.forearmL.setMatrix(forearmLMatrix);

        // //modifications forearm right
        var rotForearmRmatrix = matMul(matMul(rotZ(0), rotY(0)), rotX(2.5));
        var transForearmRmatrix = translation(this.forearmRightTranslation.x, this.forearmRightTranslation.y - this.armLength / 2, this.forearmRightTranslation.z)
        var forearmRMatrix = matMul(transForearmRmatrix, matMul(rotForearmRmatrix, this.forearmRMatrix));
        forearmRMatrix = new THREE.Matrix4().multiplyMatrices(armRMatrix, forearmRMatrix);
        this.forearmR.setMatrix(forearmRMatrix);

        //modifications hand left
        var handLMatrix = new THREE.Matrix4().multiplyMatrices(forearmLMatrix, this.handLMatrix);
        this.handL.setMatrix(handLMatrix);

        //modifications hand right
        var handRMatrix = new THREE.Matrix4().multiplyMatrices(forearmRMatrix, this.handRMatrix);
        this.handR.setMatrix(handRMatrix);

        //modifications leg left
        var rotLegLmatrix = matMul(matMul(rotZ(0), rotY(Math.PI / 2)), rotX(1));
        var transLegLmatrix = translation(this.legLeftTranslation.x, this.legLeftTranslation.y - this.spineLength / 2, this.legLeftTranslation.z)
        var legLMatrix = matMul(transLegLmatrix, matMul(rotLegLmatrix, this.legLMatrix));
        legLMatrix = new THREE.Matrix4().multiplyMatrices(this.spineMatrix, legLMatrix);
        this.legL.setMatrix(legLMatrix);

        //modifications lef right
        var rotLegRmatrix = matMul(matMul(rotZ(0), rotY(0)), rotX(Math.PI));
        var transLegRmatrix = translation(this.legRightTranslation.x, this.legRightTranslation.y - this.spineLength / 2, this.legRightTranslation.z)
        var legRMatrix = matMul(transLegRmatrix, matMul(rotLegRmatrix, this.legRMatrix));
        legRMatrix = new THREE.Matrix4().multiplyMatrices(this.spineMatrix, legRMatrix);
        this.legR.setMatrix(legRMatrix);

        //modifications shin left
        var rotShinLmatrix = matMul(matMul(rotZ(0), rotY(0)), rotX(2.4));
        var transShinLmatrix = translation(this.shinLeftTranslation.x, this.shinLeftTranslation.y - this.legLength / 2, this.shinLeftTranslation.z)
        var shinLMatrix = matMul(transShinLmatrix, matMul(rotShinLmatrix, this.shinLMatrix));
        shinLMatrix = new THREE.Matrix4().multiplyMatrices(legLMatrix, shinLMatrix);
        this.shinL.setMatrix(shinLMatrix);

        //modifications shin right
        var rotShinRmatrix = matMul(matMul(rotZ(0), rotY(0)), rotX(0));
        var transShinRmatrix = translation(this.shinRightTranslation.x, this.shinRightTranslation.y - this.legLength / 2, this.shinRightTranslation.z)
        var shinRMatrix = matMul(transShinRmatrix, matMul(rotShinRmatrix, this.shinRMatrix));
        shinRMatrix = new THREE.Matrix4().multiplyMatrices(legRMatrix, shinRMatrix);
        this.shinR.setMatrix(shinRMatrix);

        //foot left
        var footLMatrix = new THREE.Matrix4().multiplyMatrices(shinLMatrix, this.footLMatrix);
        this.footL.setMatrix(footLMatrix);

        //foot right
        var footRMatrix = new THREE.Matrix4().multiplyMatrices(shinRMatrix, this.footRMatrix);
        this.footR.setMatrix(footRMatrix);

        // le set des nouvelles matrice de transformation pour shader
        for (var key in boneDict) {
            if(key == "Spine"){
                boneDict[key].matrix = matMul(spineMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Chest"){
                boneDict[key].matrix = matMul(chestMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Neck"){
                boneDict[key].matrix =  matMul(neckMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Head"){
                boneDict[key].matrix =  matMul(headMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Arm_L"){
                boneDict[key].matrix = matMul(armLMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Forearm_L"){
                boneDict[key].matrix =  matMul(forearmLMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Arm_R"){
                boneDict[key].matrix =  matMul(armRMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Forearm_R"){
                boneDict[key].matrix =  matMul(forearmRMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Leg_L"){
                boneDict[key].matrix =  matMul(legLMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Shin_L"){
                boneDict[key].matrix =  matMul(shinLMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Leg_R"){
                boneDict[key].matrix =  matMul(legRMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Shin_R"){
                boneDict[key].matrix =  matMul(shinRMatrix, inverseOf(boneDict[key].matrix));
            }
        }

        buildShaderBoneMatrix();
    }

    animate(t) {
        robot.hideSupp();
        var vitesse = 6.5;

        //spine
        this.spineMatrix = new THREE.Matrix4().set(

            1, 0, 0, 0,
            0, 1, 0, this.spineTranslation.y + this.spineLength / 2,
            0, 0, 1, 0,
            0, 0, 0, 1);

        var spineMatrix = new THREE.Matrix4().multiplyMatrices(rotX(0), this.spineMatrix);
        this.spine.setMatrix(spineMatrix);

        // chest
        var chestMatrix = new THREE.Matrix4().multiplyMatrices(spineMatrix, this.chestMatrix);
        this.chest.setMatrix(chestMatrix);

        // neck
        var neckMatrix = new THREE.Matrix4().multiplyMatrices(chestMatrix, this.neckMatrix);
        this.neck.setMatrix(neckMatrix);

        // head
        var headMatrix = new THREE.Matrix4().multiplyMatrices(neckMatrix, this.headMatrix);
        this.head.setMatrix(headMatrix);

        // modifications arm left
        var rotArmLmatrix = matMul(matMul(rotZ(0), rotY(0)), rotX(3.3 + sin(t * vitesse) / 2));
        var transArmLmatrix = translation(this.armLeftTranslation.x, this.armLeftTranslation.y - this.chestLength / 2, this.armLeftTranslation.z)
        var armLMatrix = matMul(transArmLmatrix, matMul(rotArmLmatrix, this.armLMatrix));
        armLMatrix = new THREE.Matrix4().multiplyMatrices(chestMatrix, armLMatrix);
        this.armL.setMatrix(armLMatrix);

        // modifications arm right
        var rotArmRmatrix = matMul(matMul(rotZ(0), rotY(0)), rotX(3.3 - sin(t * vitesse) / 2));
        var transArmRmatrix = translation(this.armRightTranslation.x, this.armRightTranslation.y - this.chestLength / 2, this.armRightTranslation.z)
        var armRMatrix = matMul(transArmRmatrix, matMul(rotArmRmatrix, this.armRMatrix));
        armRMatrix = new THREE.Matrix4().multiplyMatrices(chestMatrix, armRMatrix);
        this.armR.setMatrix(armRMatrix);

        //modifications forearm left
        var rotForearmLmatrix = matMul(matMul(rotZ(0), rotY(0)), rotX(-3.8 / 2));
        var transForearmLmatrix = translation(this.forearmLeftTranslation.x, this.forearmLeftTranslation.y - this.armLength / 2, this.forearmLeftTranslation.z)
        var forearmLMatrix = matMul(transForearmLmatrix, matMul(rotForearmLmatrix, this.forearmLMatrix));
        forearmLMatrix = new THREE.Matrix4().multiplyMatrices(armLMatrix, forearmLMatrix);
        this.forearmL.setMatrix(forearmLMatrix);

        //modifications forearm right
        var rotForearmRmatrix = matMul(matMul(rotZ(0), rotY(0)), rotX(-3.8 / 2));
        var transForearmRmatrix = translation(this.forearmRightTranslation.x, this.forearmRightTranslation.y - this.armLength / 2, this.forearmRightTranslation.z)
        var forearmRMatrix = matMul(transForearmRmatrix, matMul(rotForearmRmatrix, this.forearmRMatrix));
        forearmRMatrix = new THREE.Matrix4().multiplyMatrices(armRMatrix, forearmRMatrix);
        this.forearmR.setMatrix(forearmRMatrix);

        //modifications hand left
        var handLMatrix = new THREE.Matrix4().multiplyMatrices(forearmLMatrix, this.handLMatrix);
        this.handL.setMatrix(handLMatrix);

        //modifications hand left
        var handRMatrix = new THREE.Matrix4().multiplyMatrices(forearmRMatrix, this.handRMatrix);
        this.handR.setMatrix(handRMatrix);

        //modifications leg left
        var rotLegLmatrix = matMul(matMul(rotZ(0), rotY(0)), rotX(2.9 - sin(t * vitesse) / 3));
        var transLegLmatrix = translation(this.legLeftTranslation.x, this.legLeftTranslation.y - this.spineLength / 2, this.legLeftTranslation.z)
        var legLMatrix = matMul(transLegLmatrix, matMul(rotLegLmatrix, this.legLMatrix));
        legLMatrix = new THREE.Matrix4().multiplyMatrices(this.spineMatrix, legLMatrix);
        this.legL.setMatrix(legLMatrix);

        //modifications lef right
        var rotLegRmatrix = matMul(matMul(rotZ(0), rotY(0)), rotX(2.9 + sin(t * vitesse) / 3));
        var transLegRmatrix = translation(this.legRightTranslation.x, this.legRightTranslation.y - this.spineLength / 2, this.legRightTranslation.z)
        var legRMatrix = matMul(transLegRmatrix, matMul(rotLegRmatrix, this.legRMatrix));
        legRMatrix = new THREE.Matrix4().multiplyMatrices(this.spineMatrix, legRMatrix);
        this.legR.setMatrix(legRMatrix);

        //modifications shin left
        var rotShinLmatrix = matMul(matMul(rotZ(0), rotY(0)), rotX(0.8 - sin(t * vitesse) / 1.5));
        var transShinLmatrix = translation(this.shinLeftTranslation.x, this.shinLeftTranslation.y - this.legLength / 2, this.shinLeftTranslation.z)
        var shinLMatrix = matMul(transShinLmatrix, matMul(rotShinLmatrix, this.shinLMatrix));
        shinLMatrix = new THREE.Matrix4().multiplyMatrices(legLMatrix, shinLMatrix);
        this.shinL.setMatrix(shinLMatrix);

        //modifications shin right
        var rotShinRmatrix = matMul(matMul(rotZ(0), rotY(0)), rotX(0.8 + sin(t * vitesse) / 1.5));
        var transShinRmatrix = translation(this.shinRightTranslation.x, this.shinRightTranslation.y - this.legLength / 2, this.shinRightTranslation.z)
        var shinRMatrix = matMul(transShinRmatrix, matMul(rotShinRmatrix, this.shinRMatrix));
        shinRMatrix = new THREE.Matrix4().multiplyMatrices(legRMatrix, shinRMatrix);
        this.shinR.setMatrix(shinRMatrix);

        //foot left
        var footLMatrix = new THREE.Matrix4().multiplyMatrices(shinLMatrix, this.footLMatrix);
        this.footL.setMatrix(footLMatrix);

        // //foot right
        var footRMatrix = new THREE.Matrix4().multiplyMatrices(shinRMatrix, this.footRMatrix);
        this.footR.setMatrix(footRMatrix);


        // le set des nouvelles matrice de transformation pour shader
        for (var key in boneDict) {
            if(key == "Spine"){
                boneDict[key].matrix = matMul(spineMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Chest"){
                boneDict[key].matrix = matMul(chestMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Neck"){
                boneDict[key].matrix =  matMul(neckMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Head"){
                boneDict[key].matrix =  matMul(headMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Arm_L"){
                boneDict[key].matrix = matMul(armLMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Forearm_L"){
                boneDict[key].matrix =  matMul(forearmLMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Arm_R"){
                boneDict[key].matrix =  matMul(armRMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Forearm_R"){
                boneDict[key].matrix =  matMul(forearmRMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Leg_L"){
                boneDict[key].matrix =  matMul(legLMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Shin_L"){
                boneDict[key].matrix =  matMul(shinLMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Leg_R"){
                boneDict[key].matrix =  matMul(legRMatrix, inverseOf(boneDict[key].matrix));
            }
            else if(key == "Shin_R"){
                boneDict[key].matrix =  matMul(shinRMatrix, inverseOf(boneDict[key].matrix));
            }
        }

        buildShaderBoneMatrix();
    }
    animate2(t){
        robot.showSupp();

        var vitesse1 = 8;
        var vitesse2 = 7;


        // spine 2eme character 
        var rotSpine2matrix = matMul(matMul(rotZ(0), rotY(Math.PI)), rotX(0));
        var spineMatrix2 = new THREE.Matrix4().multiplyMatrices(rotSpine2matrix, this.spineMatrix)
        this.spine2.setMatrix(spineMatrix2);

        // spine
        this.spineMatrix = new THREE.Matrix4().set(

            1, 0, 0, 0,
            0, 1, 0, this.spineTranslation.y + this.spineLength / 2,
            0, 0, 1, -2,
            0, 0, 0, 1);

        var rotSpineMatrix = matMul(matMul(rotZ(0), rotY(0)), rotX(0));
        var transSpineMatrix = translation(this.armLeftTranslation.x, this.armLeftTranslation.y - this.chestLength / 2 - 0.9, this.armLeftTranslation.z)
        var spineMatrix = matMul(transSpineMatrix, matMul(rotSpineMatrix, this.spineMatrix));
        this.spine.setMatrix(spineMatrix);

        // chest
        var chestMatrix = new THREE.Matrix4().multiplyMatrices(spineMatrix, this.chestMatrix);
        this.chest.setMatrix(chestMatrix);

        // chest 2eme character 
        var chestMatrix2 = new THREE.Matrix4().multiplyMatrices(spineMatrix2, this.chestMatrix);
        this.chest2.setMatrix(chestMatrix2);

        // neck
        var neckMatrix = new THREE.Matrix4().multiplyMatrices(chestMatrix, this.neckMatrix);
        this.neck.setMatrix(neckMatrix);
        
        // neck 2eme character 
        var neckMatrix2 = new THREE.Matrix4().multiplyMatrices(chestMatrix2, this.neckMatrix);
        this.neck2.setMatrix(neckMatrix2);

        // head
        var headMatrix = new THREE.Matrix4().multiplyMatrices(neckMatrix, this.headMatrix);
        this.head.setMatrix(headMatrix);

        // head 2eme character 
        var headMatrix2 = new THREE.Matrix4().multiplyMatrices(neckMatrix2, this.headMatrix);
        this.head2.setMatrix(headMatrix2);

        // modifications arm left 2eme character
        var rotArmL2matrix = matMul(matMul(rotZ(-1 - sin(t * vitesse2)/1.5), rotY(1)), rotX(-0.2));
        var transArmL2matrix = translation(this.armLeftTranslation.x, this.armLeftTranslation.y - this.chestLength / 2, this.armLeftTranslation.z)
        var armLMatrix2 = matMul(transArmL2matrix, matMul(rotArmL2matrix, this.armLMatrix));
        armLMatrix2 = new THREE.Matrix4().multiplyMatrices(chestMatrix2, armLMatrix2);
        this.armL2.setMatrix(armLMatrix2);

        // modifications arm left
        var rotArmLmatrix = matMul(matMul(rotZ(-3.5 + sin(t * vitesse1) ), rotY(1)), rotX(-0.2+ (sin(t* vitesse1))));
        var transArmLmatrix = translation(this.armLeftTranslation.x, this.armLeftTranslation.y - this.chestLength / 2, this.armLeftTranslation.z)
        var armLMatrix = matMul(transArmLmatrix, matMul(rotArmLmatrix, this.armLMatrix));
        armLMatrix = new THREE.Matrix4().multiplyMatrices(chestMatrix, armLMatrix);
        this.armL.setMatrix(armLMatrix);

        // modifications arm right 2eme character
        var rotArmR2matrix = matMul(matMul(rotZ(1 + sin(t * vitesse2)/1.5), rotY(-1)), rotX(0.2));
        var transArmR2matrix = translation(this.armRightTranslation.x, this.armRightTranslation.y - this.chestLength / 2, this.armRightTranslation.z)
        var armRMatrix2 = matMul(transArmR2matrix, matMul(rotArmR2matrix, this.armRMatrix));
        armRMatrix2 = new THREE.Matrix4().multiplyMatrices(chestMatrix2, armRMatrix2);
        this.armR2.setMatrix(armRMatrix2);

        // modifications arm right 
        var rotArmRmatrix = matMul(matMul(rotZ(-4 - sin(t * vitesse1)), rotY(-1)), rotX(0.5 + (sin(t * vitesse1))));
        var transArmRmatrix = translation(this.armRightTranslation.x, this.armRightTranslation.y - this.chestLength / 2, this.armRightTranslation.z)
        var armRMatrix = matMul(transArmRmatrix, matMul(rotArmRmatrix, this.armRMatrix));
        armRMatrix = new THREE.Matrix4().multiplyMatrices(chestMatrix, armRMatrix);
        this.armR.setMatrix(armRMatrix);

        //modifications forearm left 2eme character
        var rotForearmL2matrix = matMul(matMul(rotZ(0), rotY(0.7)), rotX(-1.5 + sin(-t * vitesse2))); //in y - (sin(t )/2)
        var transForearmL2matrix = translation(this.forearmLeftTranslation.x, this.forearmLeftTranslation.y - this.armLength / 2, this.forearmLeftTranslation.z)
        var forearmLMatrix2 = matMul(transForearmL2matrix, matMul(rotForearmL2matrix, this.forearmLMatrix));
        forearmLMatrix2 = new THREE.Matrix4().multiplyMatrices(armLMatrix2, forearmLMatrix2);
        this.forearmL2.setMatrix(forearmLMatrix2);

        //modifications forearm left
        var rotForearmLmatrix = matMul(matMul(rotZ(2), rotY(0)), rotX(0)); //in y - (sin(t )/2)
        var transForearmLmatrix = translation(this.forearmLeftTranslation.x, this.forearmLeftTranslation.y - this.armLength / 2, this.forearmLeftTranslation.z)
        var forearmLMatrix = matMul(transForearmLmatrix, matMul(rotForearmLmatrix, this.forearmLMatrix));
        forearmLMatrix = new THREE.Matrix4().multiplyMatrices(armLMatrix, forearmLMatrix);
        this.forearmL.setMatrix(forearmLMatrix);

        //modifications forearm right 2eme character
        var rotForearmR2matrix = matMul(matMul(rotZ(0.3), rotY(0)), rotX(-1.5 - sin(t * vitesse2)));
        var transForearmR2matrix = translation(this.forearmRightTranslation.x, this.forearmRightTranslation.y - this.armLength / 2, this.forearmRightTranslation.z)
        var forearmRMatrix2 = matMul(transForearmR2matrix, matMul(rotForearmR2matrix, this.forearmRMatrix));
        forearmRMatrix2 = new THREE.Matrix4().multiplyMatrices(armRMatrix2, forearmRMatrix2);
        this.forearmR2.setMatrix(forearmRMatrix2);

        //modifications forearm right
        var rotForearmRmatrix = matMul(matMul(rotZ(-1.7), rotY(0)), rotX(0.3));
        var transForearmRmatrix = translation(this.forearmRightTranslation.x, this.forearmRightTranslation.y - this.armLength / 2, this.forearmRightTranslation.z)
        var forearmRMatrix = matMul(transForearmRmatrix, matMul(rotForearmRmatrix, this.forearmRMatrix));
        forearmRMatrix = new THREE.Matrix4().multiplyMatrices(armRMatrix, forearmRMatrix);
        this.forearmR.setMatrix(forearmRMatrix);

        //modifications hand left
        var handLMatrix = new THREE.Matrix4().multiplyMatrices(forearmLMatrix, this.handLMatrix);
        this.handL.setMatrix(handLMatrix);

        //modifications hand left 2eme character
        var handLMatrix2 = new THREE.Matrix4().multiplyMatrices(forearmLMatrix2, this.handLMatrix);
        this.handL2.setMatrix(handLMatrix2);

        //modifications hand right
        var handRMatrix = new THREE.Matrix4().multiplyMatrices(forearmRMatrix, this.handRMatrix);
        this.handR.setMatrix(handRMatrix);

        //modifications hand right 2eme character
        var handRMatrix2 = new THREE.Matrix4().multiplyMatrices(forearmRMatrix2, this.handRMatrix);
        this.handR2.setMatrix(handRMatrix2);

        //modifications leg left 2eme character
        var rotLegL2matrix = matMul(matMul(rotZ(this.legLeftRotation.z), rotY(this.legLeftRotation.y)), rotX(-this.legLeftRotation.x));
        var transLegL2matrix = translation(this.legLeftTranslation.x, this.legLeftTranslation.y - this.spineLength / 2, this.legLeftTranslation.z)
        var legLMatrix2 = matMul(transLegL2matrix, matMul(rotLegL2matrix, this.legLMatrix));
        legLMatrix2 = new THREE.Matrix4().multiplyMatrices(spineMatrix2, legLMatrix2);
        this.legL2.setMatrix(legLMatrix2);

        //modifications leg left
        var rotLegLmatrix = matMul(matMul(rotZ(this.legLeftRotation.z), rotY(-0.4 - (sin(t * vitesse1)/1.8))), rotX(1.2));
        var transLegLmatrix = translation(this.legLeftTranslation.x, this.legLeftTranslation.y - this.spineLength / 2, this.legLeftTranslation.z)
        var legLMatrix = matMul(transLegLmatrix, matMul(rotLegLmatrix, this.legLMatrix));
        legLMatrix = new THREE.Matrix4().multiplyMatrices(spineMatrix, legLMatrix);
        this.legL.setMatrix(legLMatrix);

        //modifications leg right 2eme character
        var rotLegR2matrix = matMul(matMul(rotZ(this.legRightRotation.z), rotY(this.legRightRotation.y)), rotX(this.legRightRotation.x));
        var transLegR2matrix = translation(this.legRightTranslation.x, this.legRightTranslation.y - this.spineLength / 2, this.legRightTranslation.z)
        var legRMatrix2 = matMul(transLegR2matrix, matMul(rotLegR2matrix, this.legRMatrix));
        legRMatrix2 = new THREE.Matrix4().multiplyMatrices(spineMatrix2, legRMatrix2);
        this.legR2.setMatrix(legRMatrix2);

        //modifications leg right
        var rotLegRmatrix = matMul(matMul(rotZ(this.legRightRotation.z), rotY(0.4 + (sin(t * vitesse1)/1.8))), rotX(1.2));
        var transLegRmatrix = translation(this.legRightTranslation.x, this.legRightTranslation.y - this.spineLength / 2, this.legRightTranslation.z)
        var legRMatrix = matMul(transLegRmatrix, matMul(rotLegRmatrix, this.legRMatrix));
        legRMatrix = new THREE.Matrix4().multiplyMatrices(spineMatrix, legRMatrix);
        this.legR.setMatrix(legRMatrix);

        //modifications shin left 2eme character
        var rotShinL2matrix = matMul(matMul(rotZ(0), rotY(0)), rotX(0));
        var transShinL2matrix = translation(this.shinLeftTranslation.x, this.shinLeftTranslation.y - this.legLength / 2, this.shinLeftTranslation.z)
        var shinLMatrix2 = matMul(transShinL2matrix, matMul(rotShinL2matrix, this.shinLMatrix));
        shinLMatrix2 = new THREE.Matrix4().multiplyMatrices(legLMatrix2, shinLMatrix2);
        this.shinL2.setMatrix(shinLMatrix2);

        //modifications shin left
        var rotShinLmatrix = matMul(matMul(rotZ(0), rotY(0)), rotX(-1.5));
        var transShinLmatrix = translation(this.shinLeftTranslation.x, this.shinLeftTranslation.y - this.legLength / 2, this.shinLeftTranslation.z)
        var shinLMatrix = matMul(transShinLmatrix, matMul(rotShinLmatrix, this.shinLMatrix));
        shinLMatrix = new THREE.Matrix4().multiplyMatrices(legLMatrix, shinLMatrix);
        this.shinL.setMatrix(shinLMatrix);

        //modifications shin right 2eme character
        var rotShinR2matrix = matMul(matMul(rotZ(0), rotY(0)), rotX(0));
        var transShinR2matrix = translation(this.shinRightTranslation.x, this.shinRightTranslation.y - this.legLength / 2, this.shinRightTranslation.z)
        var shinRMatrix2 = matMul(transShinR2matrix, matMul(rotShinR2matrix, this.shinRMatrix));
        shinRMatrix2 = new THREE.Matrix4().multiplyMatrices(legRMatrix2, shinRMatrix2);
        this.shinR2.setMatrix(shinRMatrix2);

        //modifications shin right
        var rotShinRmatrix = matMul(matMul(rotZ(0), rotY(0)), rotX(-1.5));
        var transShinRmatrix = translation(this.shinRightTranslation.x, this.shinRightTranslation.y - this.legLength / 2, this.shinRightTranslation.z)
        var shinRMatrix = matMul(transShinRmatrix, matMul(rotShinRmatrix, this.shinRMatrix));
        shinRMatrix = new THREE.Matrix4().multiplyMatrices(legRMatrix, shinRMatrix);
        this.shinR.setMatrix(shinRMatrix);

        //foot left
        var rotFootLmatrix = matMul(matMul(rotZ(0), rotY(-0.2)), rotX(0));
        var transFootLmatrix = translation(0, 0, 0)
        var footLMatrix = matMul(transFootLmatrix, matMul(rotFootLmatrix, this.footLMatrix));
        footLMatrix = new THREE.Matrix4().multiplyMatrices(shinLMatrix, footLMatrix);
        this.footL.setMatrix(footLMatrix);

        //foot left 2eme character
        var footLMatrix2 = new THREE.Matrix4().multiplyMatrices(shinLMatrix2, this.footLMatrix);
        this.footL2.setMatrix(footLMatrix2);

        //foot right
        var footRMatrix = new THREE.Matrix4().multiplyMatrices(shinRMatrix, this.footRMatrix);
        this.footR.setMatrix(footRMatrix);

        //foot right 2eme character
        var footRMatrix2 = new THREE.Matrix4().multiplyMatrices(shinRMatrix2, this.footRMatrix);
        this.footR2.setMatrix(footRMatrix2);

    }
    hideSupp(){
        this.spine2.visible = false;
        this.chest2.visible = false;
        this.neck2.visible = false;
        this.head2.visible = false;
        this.armL2.visible = false;
        this.armR2.visible = false;
        this.forearmL2.visible = false;
        this.forearmR2.visible = false;
        this.handL2.visible = false;
        this.handR2.visible = false;
        this.legL2.visible = false;
        this.legR2.visible = false;
        this.shinL2.visible = false;
        this.shinR2.visible = false;
        this.footL2.visible = false;
        this.footR2.visible = false;
    }
    showSupp(){
        this.spine2.visible = true;
        this.chest2.visible = true;
        this.neck2.visible = true;
        this.head2.visible = true;
        this.armL2.visible = true;
        this.armR2.visible = true;
        this.forearmL2.visible = true;
        this.forearmR2.visible = true;
        this.handL2.visible = true;
        this.handR2.visible = true;
        this.legL2.visible = true;
        this.legR2.visible = true;
        this.shinL2.visible = true;
        this.shinR2.visible = true;
        this.footL2.visible = true;
        this.footR2.visible = true;
    }

    
}

function inverseOf(M) {

    var r = M.clone();

    return r.invert();

}
var keyboard = new THREEx.KeyboardState();
var channel = 'p';
var pi = Math.PI;

function init() {

    container = document.getElementById('container');

    camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 2000);
    camera.position.set(8, 10, 8);
    camera.lookAt(0, 3, 0);

    scene = new THREE.Scene();
    scene.add(camera);

    controls = new OrbitControls(camera, container);
    controls.damping = 0.2;

    clock = new THREE.Clock();

    boneDict = {}

    boneArray = new Float32Array(12 * 16);

    humanMaterial = new THREE.ShaderMaterial({
        uniforms: {
            bones: {
                value: boneArray
            }
        }
    });

    const shaderLoader = new THREE.FileLoader();
    shaderLoader.load('glsl/human.vs.glsl',
        function (data) {
            humanMaterial.vertexShader = data;
        })
    shaderLoader.load('glsl/human.fs.glsl',
        function (data) {
            humanMaterial.fragmentShader = data;
        })

    // loading manager

    const loadingManager = new THREE.LoadingManager(function () {
        scene.add(humanMesh);
    });

    // collada
    humanGeometry = new THREE.BufferGeometry();
    const loader = new ColladaLoader(loadingManager);
    loader.load('./model/human.dae', function (collada) {
        skinIndices = collada.library.geometries['human-mesh'].build.triangles.data.attributes.skinIndex.array;
        skinWeight = collada.library.geometries['human-mesh'].build.triangles.data.attributes.skinWeight.array;
        realBones = collada.library.nodes.human.build.skeleton.bones;

        buildSkeleton();
        buildShaderBoneMatrix();
        humanGeometry.setAttribute('position', new THREE.BufferAttribute(collada.library.geometries['human-mesh'].build.triangles.data.attributes.position.array, 3));
        humanGeometry.setAttribute('skinWeight', new THREE.BufferAttribute(skinWeight, 4));
        humanGeometry.setAttribute('skinIndex', new THREE.BufferAttribute(skinIndices, 4));
        humanGeometry.setAttribute('normal', new THREE.BufferAttribute(collada.library.geometries['human-mesh'].build.triangles.data.attributes.normal.array, 3));

        humanMesh = new THREE.Mesh(humanGeometry, humanMaterial);
        robot = new Robot(humanMesh);
        robot.hideHuman();

    });

    //

    const ambientLight = new THREE.AmbientLight(0xcccccc, 0.4);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(1, 1, 0).normalize();
    scene.add(directionalLight);

    //

    renderer = new THREE.WebGLRenderer();
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.setSize(window.innerWidth, window.innerHeight);
    container.appendChild(renderer.domElement);

    //

    stats = new Stats();
    container.appendChild(stats.dom);

    //

    window.addEventListener('resize', onWindowResize);
    lights = [];
    lights[0] = new THREE.PointLight(0xffffff, 1, 0);
    lights[1] = new THREE.PointLight(0xffffff, 1, 0);
    lights[2] = new THREE.PointLight(0xffffff, 1, 0);

    lights[0].position.set(0, 200, 0);
    lights[1].position.set(100, 200, 100);
    lights[2].position.set(- 100, - 200, - 100);

    scene.add(lights[0]);
    scene.add(lights[1]);
    scene.add(lights[2]);

    var floorTexture = new THREE.ImageUtils.loadTexture('textures/hardwood2_diffuse.jpg');
    floorTexture.wrapS = floorTexture.wrapT = THREE.RepeatWrapping;
    floorTexture.repeat.set(4, 4);

    var floorMaterial = new THREE.MeshBasicMaterial({
        map: floorTexture,
        side: THREE.DoubleSide
    });
    var floorGeometry = new THREE.PlaneBufferGeometry(30, 30);
    var floor = new THREE.Mesh(floorGeometry, floorMaterial);
    floor.rotation.x = Math.PI / 2;
    floor.position.y -= 2.5;
    scene.add(floor);

}


function buildSkeleton() {
    boneDict["Spine"] = new THREE.Bone();
    boneDict["Chest"] = new THREE.Bone();
    boneDict["Neck"] = new THREE.Bone();
    boneDict["Head"] = new THREE.Bone();
    boneDict["Arm_L"] = new THREE.Bone();
    boneDict["Forearm_L"] = new THREE.Bone();
    boneDict["Arm_R"] = new THREE.Bone();
    boneDict["Forearm_R"] = new THREE.Bone();
    boneDict["Leg_L"] = new THREE.Bone();
    boneDict["Shin_L"] = new THREE.Bone();
    boneDict["Leg_R"] = new THREE.Bone();
    boneDict["Shin_R"] = new THREE.Bone();


    boneDict['Chest'].matrixWorld = matMul(boneDict['Spine'].matrixWorld, realBones[1].matrix);
    boneDict['Neck'].matrixWorld = matMul(boneDict['Chest'].matrixWorld, realBones[2].matrix);
    boneDict['Head'].matrixWorld = matMul(boneDict['Neck'].matrixWorld, realBones[3].matrix);
    boneDict['Arm_L'].matrixWorld = matMul(boneDict['Chest'].matrixWorld, realBones[4].matrix);
    boneDict['Forearm_L'].matrixWorld = matMul(boneDict['Arm_L'].matrixWorld, realBones[5].matrix);
    boneDict['Arm_R'].matrixWorld = matMul(boneDict['Chest'].matrixWorld, realBones[6].matrix);
    boneDict['Forearm_R'].matrixWorld = matMul(boneDict['Arm_R'].matrixWorld, realBones[7].matrix);
    boneDict['Leg_L'].matrixWorld = matMul(boneDict['Spine'].matrixWorld, realBones[8].matrix);
    boneDict['Shin_L'].matrixWorld = matMul(boneDict['Leg_L'].matrixWorld, realBones[9].matrix);
    boneDict['Leg_R'].matrixWorld = matMul(boneDict['Spine'].matrixWorld, realBones[10].matrix);
    boneDict['Shin_R'].matrixWorld = matMul(boneDict['Leg_R'].matrixWorld, realBones[11].matrix);




}

/**
* Fills the Float32Array boneArray with the bone matrices to be passed to
* the vertex shader
*/
function buildShaderBoneMatrix() {
    var c = 0;
    for (var key in boneDict) {
        for (var i = 0; i < 16; i++) {
            boneArray[c++] = boneDict[key].matrix.elements[i];
        }
        
    }
    // console.log(boneArray);
}

function onWindowResize() {

    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();

    renderer.setSize(window.innerWidth, window.innerHeight);

}

function animate() {

    checkKeyboard();

    updateBody();
    requestAnimationFrame(animate);
    render();
    stats.update();

}

function render() {

    const delta = clock.getDelta();

    renderer.render(scene, camera);

}

/**
* Returns a new Matrix4 as a multiplcation of m1 and m2
*
* @param {Matrix4} m1 The first matrix
* @param {Matrix4} m2 The second matrix
* @return {Matrix4} m1 x m2
*/
function matMul(m1, m2) {
    return new THREE.Matrix4().multiplyMatrices(m1, m2);
}

/**
* Returns a new Matrix4 as a scalar multiplcation of s and m
*
* @param {number} s The scalar
* @param {Matrix4} m The  matrix
* @return {Matrix4} s * m2
*/
function scalarMul(s, m) {
    var r = m;
    return r.multiplyScalar(s)
}

/**
* Returns an array containing the x,y and z translation component 
* of a transformation matrix
*
* @param {Matrix4} M The transformation matrix
* @return {Array} x,y,z translation components
*/
function getTranslationValues(M) {
    var elems = M.elements;
    return elems.slice(12, 15);
}

/**
* Returns a new Matrix4 as a translation matrix of [x,y,z]
*
* @param {number} x x component
* @param {number} y y component
* @param {number} z z component
* @return {Matrix4} The translation matrix of [x,y,z]
*/
function translation(x, y, z) {
    //TODO Définir cette fonction

    return new THREE.Matrix4().set(
        1, 0, 0, x,
        0, 1, 0, y,
        0, 0, 1, z,
        0, 0, 0, 1);
}

/**
* Returns a new Matrix4 as a rotation matrix of theta radians around the x-axis
*
* @param {number} theta The angle expressed in radians
* @return {Matrix4} The rotation matrix of theta rad around the x-axis
*/
function rotX(theta) {
    //TODO Définir cette fonction
    // faut-il ramener la translation actuelle pour la derniere colone?(point initional b)
    return new THREE.Matrix4().set(
        1, 0, 0, 0,
        0, cos(theta), -sin(theta), 0,
        0, sin(theta), cos(theta), 0,
        0, 0, 0, 1);
}

/**
* Returns a new Matrix4 as a rotation matrix of theta radians around the y-axis
*
* @param {number} theta The angle expressed in radians
* @return {Matrix4} The rotation matrix of theta rad around the y-axis
*/
function rotY(theta) {
    //TODO Définir cette fonction
    // cos(theta), -sin(theta)
    return new THREE.Matrix4().set(
        cos(theta), 0, sin(theta), 0,
        0, 1, 0, 0,
        -sin(theta), 0, cos(theta), 0,
        0, 0, 0, 1);
}

/**
* Returns a new Matrix4 as a rotation matrix of theta radians around the z-axis
*
* @param {number} theta The angle expressed in radians
* @return {Matrix4} The rotation matrix of theta rad around the z-axis
*/
function rotZ(theta) {
    //TODO Définir cette fonction
    // cos(theta) -sin(theta)
    return new THREE.Matrix4().set(
        cos(theta), -sin(theta), 0, 0,
        sin(theta), cos(theta), 0, 0,
        0, 0, 1, 0,
        0, 0, 0, 1);
}

/**
* Returns a new Matrix4 as a scaling matrix with factors of x,y,z
*
* @param {number} x x component
* @param {number} y y component
* @param {number} z z component
* @return {Matrix4} The scaling matrix with factors of x,y,z
*/
function scale(x, y, z) {
    //TODO Définir cette fonction
    return new THREE.Matrix4().set(
        x, 0, 0, 0,
        0, y, 0, 0,
        0, 0, z, 0,
        0, 0, 0, 1);
}

function cos(angle) {
    return Math.cos(angle);
}

function sin(angle) {
    return Math.sin(angle);
}

function checkKeyboard() {
    for (var i = 0; i < 10; i++) {
        if (keyboard.pressed(i.toString())) {
            channel = i;
            break;
        }
    }
}
function updateBody() {

    switch (channel) {
        case 0:
            var t = clock.getElapsedTime();
            robot.animate(t);
            break;

        // add poses here:
        case 1:
            robot.pose1();
            break;

        case 2:
            robot.pose2();
            break;

        case 3:
            var t = clock.getElapsedTime();
            robot.animate2(t);
            break;

        case 4:
            break;

        case 5:
            break;
        case 6:
            robot.hideRobot();
            break;
        case 7:
            robot.showRobot();
            break;
        case 8:
            robot.hideHuman();
            break;
        case 9:
            robot.showHuman();
            break;
        default:
            break;
    }
}

init();
animate();
